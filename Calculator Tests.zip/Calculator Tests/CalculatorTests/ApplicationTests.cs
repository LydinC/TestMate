﻿using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Remote;
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
namespace TestSuite
{

    [TestFixture]
    public class Tests
    {
        private AndroidDriver<AndroidElement> _driver;
        
        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            // Accessing the capabilities through TestContext parameters
            string appiumServerUrl = TestContext.Parameters["AppiumServerUrl"];
            string udid = TestContext.Parameters["UDID"];
            string app = TestContext.Parameters["APP"];

            // Initializing the Appium driver using the provided capabilities
            AppiumOptions appiumOptions = new AppiumOptions();
            appiumOptions.AddAdditionalCapability("appium:udid", udid);
            appiumOptions.AddAdditionalCapability("appium:app", app);
            appiumOptions.AddAdditionalCapability("newCommandTimeout", 500);
            appiumOptions.AddAdditionalCapability("uiautomator2ServerInstallTimeout", 90000);
            _driver = new AndroidDriver<AndroidElement>(new Uri(appiumServerUrl), appiumOptions);
        }

        [SetUp]
        public void Setup()
        {
            Console.WriteLine("Launching App");
            _driver.LaunchApp();
        }

        [Test]
        public void Test_simpleAddOperation_verifyResult()
        {
            Console.WriteLine("Starting Addition Operation Test");
            ClickButton("digit_2");
            ClickButton("op_add");
            ClickButton("digit_7");

            AssertFormula("2+7");
            AssertResult("9");
        }

        [Test]
        public void Test_simpleMulOperation_verifyResult()
        {
            Console.WriteLine("Starting Multiply Operation Test");
            ClickButton("digit_7");
            ClickButton("op_mul");
            ClickButton("digit_2");

            AssertFormula("7×2");
            AssertResult("14");
        }

        [Test]
        public void Test_simpleSubOperation_verifyResult()
        {
            Console.WriteLine("Starting Subtraction Operation Test");
            ClickButton("digit_9");
            ClickButton("op_sub");
            ClickButton("digit_3");

            AssertFormula("9−3");
            AssertResult("6");
        }

        [Test]
        public void Test_simpleDivOperation_verifyResult()
        {
            Console.WriteLine("Starting Division Operation Test");
            
            ClickButton("digit_8");
            ClickButton("op_div");
            ClickButton("digit_4");

            AssertFormula("8÷4");
            AssertResult("2");
        }

        private void ClickButton(string identifier) {
            _driver.FindElementById("com.xlythe.calculator.material:id/" + identifier).Click();
        }

        private void AssertFormula(string formula)
        {
            Assert.AreEqual(formula, _driver.FindElementById("com.xlythe.calculator.material:id/formula").GetAttribute("text"));
        }
        private void AssertResult(string result)
        {
            Assert.AreEqual(result, _driver.FindElementById("com.xlythe.calculator.material:id/result").GetAttribute("text"));
        }

        [TearDown]
        public void TearDown()
        {
            Console.WriteLine("Closing App");
            _driver.CloseApp();
        }

        [OneTimeTearDown]
        public void OneTimeTearDown()
        {
            if (_driver != null)
            {
                Console.WriteLine("OneTimeTearDown");
                _driver.RemoveApp("com.xlythe.calculator.material");
                _driver.Dispose();
                _driver.Quit();
            }
        }

    }
}
